import pyodbc
import pandas as pd

driver="{ODBC Driver 17 for SQL Server}"
server="S01V09931569"
port="1435" #Linux can't resolve instance names. Using port 1435 instead of instance name IT2243401PS
user="V3ETLUSR"
pwd="VE3tlusr*42395"
db="TEST_DATALAB"
table="dbo.TEST_TRAGHETTO_SQL_SERVER"

connection_string='DRIVER={0};SERVER={1},{2};DATABASE={3};UID={4};PWD={5}'.format(driver, server, port, db, user, pwd)
print(connection_string)

cnxn = pyodbc.connect(connection_string)
print("Connected to DB.")

with cnxn:
    try:
        req="SELECT * FROM {t};".format(t=table)
        print("Execute query: ")
        print(req)
        df = pd.read_sql(req, cnxn)
        print("Results: ")
        print(df)
    except Exception as ex:
        print(ex)